from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone

from database.models import User, PaymentProvider
from database.repo import (
    UserRepo, SubscriptionRepo, PaymentRepo,
    PlanRepo, WithdrawalRepo, ReferralRepo
)
from keyboards import (
    admin_main_kb, admin_withdrawal_kb,
    admin_user_kb, admin_broadcast_confirm_kb
)
from services.redis_service import redis_service
from config import settings

router = Router()


def is_admin(user: User) -> bool:
    return user.is_admin or user.telegram_id in settings.ADMIN_IDS


class AdminStates(StatesGroup):
    broadcast_text = State()
    find_user = State()
    gift_days = State()
    add_balance = State()


# ─── ADMIN GUARD ─────────────────────────────────────────────────────────────

def admin_only(handler):
    async def wrapper(event, user: User, **kwargs):
        if not is_admin(user):
            if isinstance(event, Message):
                await event.answer("🚫 Ruxsat yo'q.")
            elif isinstance(event, CallbackQuery):
                await event.answer("🚫 Ruxsat yo'q.", show_alert=True)
            return
        return await handler(event, user=user, **kwargs)
    return wrapper


@router.message(Command("admin"))
async def cmd_admin(message: Message, user: User):
    if not is_admin(user):
        return
    await message.answer("⚙️ <b>Admin Panel</b>", reply_markup=admin_main_kb(), parse_mode="HTML")


@router.callback_query(F.data == "admin:stats")
async def admin_stats(call: CallbackQuery, user: User, db: AsyncSession):
    if not is_admin(user):
        return

    user_repo = UserRepo(db)
    pay_repo = PaymentRepo(db)
    sub_repo = SubscriptionRepo(db)

    total_users = await user_repo.count_total()
    total_revenue = await pay_repo.total_revenue()

    # Count active subs
    from sqlalchemy import select, func
    from database.models import Subscription, SubscriptionStatus
    result = await db.execute(
        select(func.count(Subscription.id))
        .where(
            Subscription.status == SubscriptionStatus.ACTIVE,
            Subscription.expires_at > datetime.now(timezone.utc),
        )
    )
    active_subs = result.scalar() or 0

    await call.message.edit_text(
        f"📊 <b>Bot statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{total_users:,}</b>\n"
        f"💎 Faol obunalar: <b>{active_subs:,}</b>\n"
        f"💰 Jami daromad: <b>{int(total_revenue):,} so'm</b>\n\n"
        f"📅 Sana: {datetime.now().strftime('%d.%m.%Y %H:%M')}",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:broadcast")
async def admin_broadcast_start(call: CallbackQuery, user: User, state: FSMContext):
    if not is_admin(user):
        return
    await state.set_state(AdminStates.broadcast_text)
    await call.message.edit_text(
        "📢 <b>Xabar yuborish</b>\n\n"
        "Barcha foydalanuvchilarga yuboriladigan xabarni yozing\n"
        "(HTML format qo'llab-quvvatlanadi):",
        parse_mode="HTML",
    )


@router.message(AdminStates.broadcast_text)
async def admin_broadcast_preview(message: Message, user: User, state: FSMContext):
    if not is_admin(user):
        return
    await redis_service.set_broadcast_message(user.telegram_id, {
        "text": message.text,
        "html": message.parse_entities(),
    })
    await message.answer(
        f"📢 <b>Ko'rinish:</b>\n\n{message.text}\n\n"
        f"Ushbu xabarni barcha foydalanuvchilarga yuborishni xohlaysizmi?",
        reply_markup=admin_broadcast_confirm_kb(),
        parse_mode="HTML",
    )
    await state.clear()


@router.callback_query(F.data == "admin:broadcast:confirm")
async def admin_broadcast_confirm(call: CallbackQuery, user: User, db: AsyncSession):
    if not is_admin(user):
        return

    msg_data = await redis_service.get_broadcast_message(user.telegram_id)
    if not msg_data:
        await call.answer("❌ Xabar topilmadi.", show_alert=True)
        return

    await call.message.edit_text("📢 Xabar yuborilmoqda...")

    user_repo = UserRepo(db)
    users = await user_repo.get_all_active()

    sent = 0
    failed = 0
    for u in users:
        try:
            await call.bot.send_message(
                u.telegram_id,
                msg_data["text"],
                parse_mode="HTML",
            )
            sent += 1
        except Exception:
            failed += 1

    await call.message.edit_text(
        f"✅ <b>Xabar yuborildi!</b>\n\n"
        f"✅ Muvaffaqiyatli: {sent}\n"
        f"❌ Muvaffaqiyatsiz: {failed}",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:broadcast:cancel")
async def admin_broadcast_cancel(call: CallbackQuery, user: User):
    if not is_admin(user):
        return
    await redis_service.delete(f"broadcast:{user.telegram_id}")
    await call.message.edit_text("❌ Bekor qilindi.", reply_markup=admin_main_kb())


@router.callback_query(F.data == "admin:withdrawals")
async def admin_withdrawals(call: CallbackQuery, user: User, db: AsyncSession):
    if not is_admin(user):
        return

    withdraw_repo = WithdrawalRepo(db)
    pending = await withdraw_repo.get_pending()

    if not pending:
        await call.message.edit_text(
            "💸 <b>Kutilayotgan pul chiqarish so'rovlari</b>\n\n"
            "Hozircha so'rovlar yo'q. ✅",
            reply_markup=admin_main_kb(),
            parse_mode="HTML",
        )
        return

    for w in pending:
        masked = f"{w.card_number[:4]} **** **** {w.card_number[-4:]}"
        await call.bot.send_message(
            call.from_user.id,
            f"💸 <b>So'rov #{w.id}</b>\n\n"
            f"👤 {w.user.full_name if w.user else 'Noma'lum'}\n"
            f"🆔 {w.user.telegram_id if w.user else '—'}\n"
            f"💳 {masked}\n"
            f"💵 {int(w.amount):,} so'm\n"
            f"📅 {w.created_at.strftime('%d.%m.%Y %H:%M')}",
            reply_markup=admin_withdrawal_kb(w.id),
            parse_mode="HTML",
        )

    await call.message.edit_text(
        f"💸 Jami {len(pending)} ta kutilayotgan so'rov yuborildi.",
        reply_markup=admin_main_kb(),
    )


@router.callback_query(F.data.startswith("admin:withdraw:approve:"))
async def admin_approve_withdrawal(call: CallbackQuery, user: User, db: AsyncSession):
    if not is_admin(user):
        return

    withdrawal_id = int(call.data.split(":")[-1])
    withdraw_repo = WithdrawalRepo(db)
    await withdraw_repo.approve(withdrawal_id, admin_note=f"Approved by {user.full_name}")

    # Notify user
    from database.models import Withdrawal
    from sqlalchemy import select
    result = await db.execute(select(Withdrawal).where(Withdrawal.id == withdrawal_id))
    w = result.scalar_one_or_none()
    if w:
        try:
            from database.repo import UserRepo
            u_repo = UserRepo(db)
            wuser = await db.get(User, w.user_id)
            if wuser:
                await call.bot.send_message(
                    wuser.telegram_id,
                    f"✅ <b>Pul chiqarish tasdiqlandi!</b>\n\n"
                    f"💵 {int(w.amount):,} so'm\n"
                    f"💳 **** {w.card_number[-4:]}\n\n"
                    f"1-2 soat ichida kartangizga tushadi.",
                    parse_mode="HTML",
                )
        except Exception:
            pass

    await call.message.edit_text(f"✅ So'rov #{withdrawal_id} tasdiqlandi.")


@router.callback_query(F.data.startswith("admin:withdraw:reject:"))
async def admin_reject_withdrawal(call: CallbackQuery, user: User, db: AsyncSession):
    if not is_admin(user):
        return

    withdrawal_id = int(call.data.split(":")[-1])
    withdraw_repo = WithdrawalRepo(db)
    await withdraw_repo.reject(withdrawal_id, admin_note=f"Rejected by {user.full_name}")

    # Refund balance
    from database.models import Withdrawal
    from sqlalchemy import select
    result = await db.execute(select(Withdrawal).where(Withdrawal.id == withdrawal_id))
    w = result.scalar_one_or_none()
    if w:
        user_repo = UserRepo(db)
        await user_repo.update_balance(w.user_id, float(w.amount))
        try:
            wuser = await db.get(User, w.user_id)
            if wuser:
                await call.bot.send_message(
                    wuser.telegram_id,
                    f"❌ <b>Pul chiqarish rad etildi.</b>\n\n"
                    f"💵 {int(w.amount):,} so'm balansingizga qaytarildi.",
                    parse_mode="HTML",
                )
        except Exception:
            pass

    await call.message.edit_text(f"❌ So'rov #{withdrawal_id} rad etildi. Balans qaytarildi.")


@router.callback_query(F.data == "admin:users")
async def admin_users(call: CallbackQuery, user: User, state: FSMContext):
    if not is_admin(user):
        return
    await state.set_state(AdminStates.find_user)
    await call.message.edit_text(
        "👥 <b>Foydalanuvchi qidirish</b>\n\n"
        "Telegram ID yoki username kiriting:",
        parse_mode="HTML",
    )


@router.message(AdminStates.find_user)
async def admin_find_user(message: Message, user: User, db: AsyncSession, state: FSMContext):
    if not is_admin(user):
        return

    query = message.text.strip().lstrip("@")
    from sqlalchemy import select, or_
    result = await db.execute(
        select(User).where(
            or_(
                User.username == query,
                User.telegram_id == (int(query) if query.isdigit() else -1),
            )
        )
    )
    found = result.scalar_one_or_none()

    if not found:
        await message.answer("❌ Foydalanuvchi topilmadi.")
        await state.clear()
        return

    sub_repo = SubscriptionRepo(db)
    sub = await sub_repo.get_active(found.id)

    await message.answer(
        f"👤 <b>Foydalanuvchi</b>\n\n"
        f"Ism: {found.full_name}\n"
        f"🆔 ID: <code>{found.telegram_id}</code>\n"
        f"💎 Obuna: {'✅ ' + sub.plan.name if sub else '❌ Yo'q'}\n"
        f"💰 Balans: {int(found.balance):,} so'm\n"
        f"🚫 Ban: {'Ha' if found.is_banned else 'Yo'q'}",
        reply_markup=admin_user_kb(found.id),
        parse_mode="HTML",
    )
    await state.clear()
