from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from typing import Callable, Dict, Any, Awaitable
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import AsyncSessionLocal
from database.repo import UserRepo, SubscriptionRepo
from services.redis_service import redis_service
from config import settings
import logging

logger = logging.getLogger(__name__)


class DatabaseMiddleware(BaseMiddleware):
    """Inject DB session into handler data."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        async with AsyncSessionLocal() as session:
            data["db"] = session
            try:
                result = await handler(event, data)
                return result
            except Exception as e:
                await session.rollback()
                raise e


class UserMiddleware(BaseMiddleware):
    """Auto-register user and inject into handler data."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, (Message, CallbackQuery)):
            tg_user = event.from_user
            if tg_user:
                db: AsyncSession = data.get("db")
                if db:
                    repo = UserRepo(db)
                    # Extract referral from start command
                    referral_code = None
                    if isinstance(event, Message) and event.text:
                        text = event.text.strip()
                        if text.startswith("/start "):
                            ref_part = text.split(" ", 1)[1].strip()
                            if ref_part.startswith("ref_"):
                                referral_code = ref_part[4:]

                    db_user, is_new = await repo.get_or_create(
                        telegram_id=tg_user.id,
                        full_name=tg_user.full_name,
                        username=tg_user.username,
                        referral_code=referral_code,
                    )

                    if is_new and db_user.referred_by_id:
                        # Give referral bonus
                        from database.repo import ReferralRepo
                        ref_repo = ReferralRepo(db)
                        inviter_repo = UserRepo(db)
                        await inviter_repo.update_balance(
                            db_user.referred_by_id,
                            float(settings.REFERRAL_BONUS_INVITER)
                        )
                        await inviter_repo.update_balance(
                            db_user.id,
                            float(settings.REFERRAL_BONUS_INVITED)
                        )
                        await ref_repo.create_bonus(
                            user_id=db_user.referred_by_id,
                            invited_user_id=db_user.id,
                            amount=float(settings.REFERRAL_BONUS_INVITER)
                        )
                        logger.info(f"Referral bonus: user {db_user.id} invited by {db_user.referred_by_id}")

                    user = db_user

        data["user"] = user
        return await handler(event, data)


class AntiSpamMiddleware(BaseMiddleware):
    """Basic anti-spam: max 30 messages per 10 seconds."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        if isinstance(event, Message):
            user_id = event.from_user.id if event.from_user else None
            if user_id:
                is_spam = await redis_service.check_rate_limit(
                    key=str(user_id), limit=30, window=10
                )
                if is_spam:
                    await event.answer("⚠️ Juda ko'p so'rov. Biroz kuting.")
                    return
        return await handler(event, data)


class BanCheckMiddleware(BaseMiddleware):
    """Check if user is banned."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("user")
        if user and user.is_banned:
            if isinstance(event, Message):
                await event.answer("🚫 Siz botdan foydalanish huquqidan mahrum etildingiz.")
            return
        return await handler(event, data)
