from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from typing import List
from database.models import SubscriptionPlan


# ─── MAIN MENU ───────────────────────────────────────────────────────────────

def main_menu_kb(is_subscribed: bool = False) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="💎 Obuna olish"),
        KeyboardButton(text="👤 Mening profilim"),
    )
    builder.row(
        KeyboardButton(text="👥 Referral tizim"),
        KeyboardButton(text="💰 Balans"),
    )
    builder.row(
        KeyboardButton(text="📞 Qo'llab-quvvatlash"),
        KeyboardButton(text="ℹ️ Ma'lumot"),
    )
    return builder.as_markup(resize_keyboard=True)


# ─── SUBSCRIPTION PLANS ──────────────────────────────────────────────────────

def plans_kb(plans: List[SubscriptionPlan]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for plan in plans:
        discount_text = f" (-{plan.discount_percent}%)" if plan.discount_percent else ""
        builder.row(
            InlineKeyboardButton(
                text=f"📦 {plan.name} — {int(plan.price):,} so'm{discount_text}",
                callback_data=f"plan:{plan.id}",
            )
        )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="back:main")
    )
    return builder.as_markup()


def payment_method_kb(plan_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="💳 Payme", callback_data=f"pay:payme:{plan_id}"),
        InlineKeyboardButton(text="🔵 Click", callback_data=f"pay:click:{plan_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🟠 Uzum Bank", callback_data=f"pay:uzum:{plan_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🎁 Balans bilan to'lash", callback_data=f"pay:balance:{plan_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="back:plans")
    )
    return builder.as_markup()


def confirm_payment_kb(plan_id: int, provider: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ To'lovni tasdiqlash",
            callback_data=f"confirm_pay:{provider}:{plan_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"pay:{provider}:{plan_id}")
    )
    return builder.as_markup()


def check_payment_kb(order_id: str, url: str = "") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if url:
        builder.row(InlineKeyboardButton(text="💳 To'lash", url=url))
    builder.row(
        InlineKeyboardButton(text="🔄 To'lovni tekshirish", callback_data=f"check_pay:{order_id}")
    )
    builder.row(
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"cancel_pay:{order_id}")
    )
    return builder.as_markup()


# ─── PROFILE ─────────────────────────────────────────────────────────────────

def profile_kb(has_subscription: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if not has_subscription:
        builder.row(
            InlineKeyboardButton(text="💎 Obuna olish", callback_data="goto:plans")
        )
    builder.row(
        InlineKeyboardButton(text="📋 To'lov tarixi", callback_data="profile:history"),
        InlineKeyboardButton(text="👥 Mening referrallarim", callback_data="profile:referrals"),
    )
    return builder.as_markup()


def payment_history_kb(page: int, total_pages: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"pay_hist:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"pay_hist:{page+1}"))
    if nav:
        builder.row(*nav)
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="back:profile"))
    return builder.as_markup()


# ─── BALANCE / REFERRAL ───────────────────────────────────────────────────────

def balance_kb(has_balance: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_balance:
        builder.row(
            InlineKeyboardButton(text="💸 Pul chiqarish", callback_data="withdraw:start"),
            InlineKeyboardButton(text="💳 Obunaga ishlatish", callback_data="balance:use"),
        )
    builder.row(
        InlineKeyboardButton(text="📊 Referral statistika", callback_data="referral:stats")
    )
    return builder.as_markup()


def withdraw_confirm_kb(amount: float) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=f"✅ {int(amount):,} so'm chiqarishni tasdiqlash",
            callback_data=f"withdraw:confirm:{int(amount)}"
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data="withdraw:cancel")
    )
    return builder.as_markup()


# ─── SUBSCRIPTION CHECK ───────────────────────────────────────────────────────

def subscription_check_kb(channel_username: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📢 Kanalga obuna bo'lish", url=f"https://t.me/{channel_username.lstrip('@')}")
    )
    builder.row(
        InlineKeyboardButton(text="✅ Tekshirish", callback_data="check:subscription")
    )
    return builder.as_markup()


# ─── SUPPORT ─────────────────────────────────────────────────────────────────

def support_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📩 Xabar yuborish", callback_data="support:message"),
        InlineKeyboardButton(text="❓ Ko'p so'raladigan savollar", callback_data="support:faq"),
    )
    return builder.as_markup()


# ─── BACK BUTTONS ────────────────────────────────────────────────────────────

def back_kb(callback: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data=callback))
    return builder.as_markup()


# ─── ADMIN KEYBOARDS ─────────────────────────────────────────────────────────

def admin_main_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Statistika", callback_data="admin:stats"),
        InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="admin:users"),
    )
    builder.row(
        InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin:broadcast"),
        InlineKeyboardButton(text="💸 Chiqarish so'rovlari", callback_data="admin:withdrawals"),
    )
    builder.row(
        InlineKeyboardButton(text="📦 Obuna rejalari", callback_data="admin:plans"),
        InlineKeyboardButton(text="⚙️ Sozlamalar", callback_data="admin:settings"),
    )
    return builder.as_markup()


def admin_withdrawal_kb(withdrawal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"admin:withdraw:approve:{withdrawal_id}"),
        InlineKeyboardButton(text="❌ Rad etish", callback_data=f"admin:withdraw:reject:{withdrawal_id}"),
    )
    return builder.as_markup()


def admin_user_kb(user_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎁 Obuna berish", callback_data=f"admin:user:gift:{user_id}"),
        InlineKeyboardButton(text="🚫 Ban", callback_data=f"admin:user:ban:{user_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="💰 Balans qo'shish", callback_data=f"admin:user:balance:{user_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin:users")
    )
    return builder.as_markup()


def admin_broadcast_confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📢 Yuborish", callback_data="admin:broadcast:confirm"),
        InlineKeyboardButton(text="❌ Bekor", callback_data="admin:broadcast:cancel"),
    )
    return builder.as_markup()
