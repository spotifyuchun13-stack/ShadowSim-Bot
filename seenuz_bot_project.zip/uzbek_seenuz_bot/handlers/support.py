from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.models import User
from keyboards import support_kb, back_kb
from config import settings

router = Router()


class SupportStates(StatesGroup):
    waiting_message = State()


FAQ = """
❓ <b>Ko'p so'raladigan savollar</b>

<b>1. Obuna qanday ishlaydi?</b>
Obuna sotib olgandan so'ng belgilangan muddat davomida premium kontentlarga kirish imkoniga ega bo'lasiz.

<b>2. To'lov qabul qilinmadi?</b>
To'lovdan 5 daqiqa o'tib "To'lovni tekshirish" tugmasini bosing. Muammo davom etsa, qo'llab-quvvatlashga murojaat qiling.

<b>3. Obunani uzaytirish mumkinmi?</b>
Ha! Obuna tugashidan oldin ham yangi obuna sotib olishingiz mumkin. U joriy obuna tugagandan boshlanadi.

<b>4. Referral bonus qachon kelib tushadi?</b>
Do'stingiz botga /start bosganidan so'ng darhol balansingizga 5,000 so'm tushadi.

<b>5. Pul chiqarish qancha vaqt oladi?</b>
1-2 ish kuni ichida ko'rsatilgan karta raqamiga o'tkaziladi.

<b>6. Minimal chiqarish miqdori qancha?</b>
Minimal pul chiqarish miqdori: 50,000 so'm.
"""


@router.message(F.text == "📞 Qo'llab-quvvatlash")
@router.message(Command("support"))
async def cmd_support(message: Message):
    await message.answer(
        "📞 <b>Qo'llab-quvvatlash</b>\n\n"
        "Savolingiz bormi? Muammoga duch keldingizmi?\n"
        "Bizga xabar yuboring yoki ko'p so'raladigan savollarga qarang.",
        reply_markup=support_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "support:faq")
async def show_faq(call: CallbackQuery):
    await call.message.edit_text(
        FAQ,
        reply_markup=back_kb("back:support"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "support:message")
async def support_message_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(SupportStates.waiting_message)
    await call.message.edit_text(
        "📩 <b>Xabar yuborish</b>\n\n"
        "Muammongizni yoki savolingizni yozing.\n"
        "Operatorimiz tez orada javob beradi.",
        reply_markup=back_kb("back:support"),
        parse_mode="HTML",
    )


@router.message(SupportStates.waiting_message)
async def support_receive_message(message: Message, user: User, state: FSMContext):
    await state.clear()

    # Forward to admins
    for admin_id in settings.ADMIN_IDS:
        try:
            await message.bot.send_message(
                admin_id,
                f"📩 <b>Yangi support xabari</b>\n\n"
                f"👤 Foydalanuvchi: {user.full_name}\n"
                f"🆔 Telegram: <code>{user.telegram_id}</code>\n\n"
                f"💬 Xabar:\n{message.text}",
                parse_mode="HTML",
            )
        except Exception:
            pass

    await message.answer(
        "✅ Xabaringiz adminga yuborildi!\n\n"
        "Tez orada javob oласиз. Rahmat!"
    )


@router.callback_query(F.data == "back:support")
async def back_to_support(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(
        "📞 <b>Qo'llab-quvvatlash</b>\n\n"
        "Savolingiz bormi? Muammoga duch keldingizmi?\n"
        "Bizga xabar yuboring yoki ko'p so'raladigan savollarga qarang.",
        reply_markup=support_kb(),
        parse_mode="HTML",
    )
