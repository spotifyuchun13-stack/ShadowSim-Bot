from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command

from database.models import User
from database.repo import SubscriptionRepo
from keyboards import main_menu_kb, subscription_check_kb
from config import settings

router = Router()


async def check_channel_membership(bot, user_id: int) -> bool:
    """Check if user is member of required channel."""
    try:
        member = await bot.get_chat_member(settings.REQUIRED_CHANNEL_ID, user_id)
        return member.status not in ("left", "kicked", "restricted")
    except Exception:
        return True  # If check fails, allow through


@router.message(CommandStart())
async def cmd_start(message: Message, user: User, db):
    sub_repo = SubscriptionRepo(db)
    is_subscribed = await sub_repo.is_active(user.id)

    # Check channel membership
    is_member = await check_channel_membership(message.bot, message.from_user.id)
    if not is_member:
        await message.answer(
            f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
            f"🎬 <b>Seenuz</b> botiga xush kelibsiz!\n\n"
            f"⚠️ Botdan foydalanish uchun avval quyidagi kanalga obuna bo'lishingiz kerak:",
            reply_markup=subscription_check_kb(settings.REQUIRED_CHANNEL_USERNAME),
            parse_mode="HTML",
        )
        return

    status_text = ""
    if is_subscribed:
        status_text = "\n✅ Sizda faol obuna mavjud."
    else:
        status_text = "\n❌ Sizda hozircha obuna yo'q."

    await message.answer(
        f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
        f"🎬 <b>Seenuz</b> botiga xush kelibsiz!\n"
        f"Premium kontentlarga cheksiz kirish imkoniyatiga ega bo'ling.{status_text}\n\n"
        f"📲 Pastdagi menyudan foydalaning:",
        reply_markup=main_menu_kb(is_subscribed),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "check:subscription")
async def check_subscription_cb(call: CallbackQuery, user: User, db):
    is_member = await check_channel_membership(call.bot, call.from_user.id)
    if not is_member:
        await call.answer("❌ Siz hali kanalga obuna bo'lmagansiz!", show_alert=True)
        return

    sub_repo = SubscriptionRepo(db)
    is_subscribed = await sub_repo.is_active(user.id)

    await call.message.edit_text(
        f"✅ Rahmat! Kanalga obuna bo'ldingiz.\n\n"
        f"🎬 <b>Seenuz</b> botiga xush kelibsiz!",
        parse_mode="HTML",
    )
    await call.message.answer(
        "📲 Pastdagi menyudan foydalaning:",
        reply_markup=main_menu_kb(is_subscribed),
    )


@router.message(F.text == "ℹ️ Ma'lumot")
async def cmd_info(message: Message):
    await message.answer(
        "ℹ️ <b>Seenuz Bot haqida</b>\n\n"
        "🎬 Seenuz — O'zbekiston premium kontent platformasi\n\n"
        "✨ <b>Imkoniyatlar:</b>\n"
        "• Cheksiz kino va seriallar\n"
        "• HD va Full HD sifat\n"
        "• O'zbek tilidagi dublyaj\n"
        "• Yangi kontentlar har hafta\n\n"
        "💎 <b>Obuna rejalar:</b>\n"
        "• 1 Oylik — 15,000 so'm\n"
        "• 3 Oylik — 35,000 so'm (22% chegirma)\n"
        "• 6 Oylik — 60,000 so'm (33% chegirma)\n"
        "• 12 Oylik — 100,000 so'm (44% chegirma)\n\n"
        "👥 <b>Referral tizim:</b>\n"
        "Do'stingizni taklif qiling va bonus oling!\n\n"
        "📞 <b>Aloqa:</b> /support",
        parse_mode="HTML",
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Yordam</b>\n\n"
        "🔸 /start — Bosh menyu\n"
        "🔸 /profile — Mening profilim\n"
        "🔸 /subscribe — Obuna olish\n"
        "🔸 /balance — Balansim\n"
        "🔸 /referral — Referral havolam\n"
        "🔸 /support — Qo'llab-quvvatlash\n",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "back:main")
async def back_to_main(call: CallbackQuery, user: User, db):
    sub_repo = SubscriptionRepo(db)
    is_subscribed = await sub_repo.is_active(user.id)
    await call.message.delete()
    await call.message.answer(
        "📲 Asosiy menyu:",
        reply_markup=main_menu_kb(is_subscribed),
    )


@router.callback_query(F.data == "goto:plans")
async def goto_plans(call: CallbackQuery):
    from handlers.subscription import show_plans
    await show_plans(call.message, call.from_user)
