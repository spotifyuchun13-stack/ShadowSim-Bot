from handlers.start import router as start_router
from handlers.subscription import router as subscription_router
from handlers.profile import router as profile_router
from handlers.referral import router as referral_router
from handlers.support import router as support_router
