from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone
import math

from database.models import User
from database.repo import SubscriptionRepo, PaymentRepo, UserRepo
from keyboards import profile_kb, payment_history_kb, back_kb

router = Router()


@router.message(F.text == "👤 Mening profilim")
@router.message(Command("profile"))
async def cmd_profile(message: Message, user: User, db: AsyncSession):
    sub_repo = SubscriptionRepo(db)
    sub = await sub_repo.get_active(user.id)

    referrals = await UserRepo(db).get_referrals(user.id)

    if sub:
        remaining = (sub.expires_at - datetime.now(timezone.utc)).days
        sub_text = (
            f"✅ Faol — <b>{sub.plan.name}</b>\n"
            f"   📅 {sub.expires_at.strftime('%d.%m.%Y')} gacha ({remaining} kun)"
        )
    else:
        sub_text = "❌ Obuna yo'q"

    reg_date = user.created_at.strftime("%d.%m.%Y") if user.created_at else "—"

    await message.answer(
        f"👤 <b>Mening profilim</b>\n\n"
        f"🆔 ID: <code>{user.telegram_id}</code>\n"
        f"👤 Ism: <b>{user.full_name}</b>\n"
        f"📅 Ro'yxatdan o'tgan: {reg_date}\n\n"
        f"💎 Obuna: {sub_text}\n\n"
        f"💰 Balans: <b>{int(user.balance):,} so'm</b>\n"
        f"👥 Taklif qilinganlar: <b>{len(referrals)}</b>\n"
        f"🎁 Referral kod: <code>{user.referral_code}</code>",
        reply_markup=profile_kb(sub is not None),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "profile:history")
async def payment_history(call: CallbackQuery, user: User, db: AsyncSession):
    pay_repo = PaymentRepo(db)
    payments = await pay_repo.get_user_history(user.id, limit=50)

    if not payments:
        await call.message.edit_text(
            "📋 <b>To'lov tarixi</b>\n\n"
            "Hozircha to'lovlar yo'q.",
            reply_markup=back_kb("back:profile"),
            parse_mode="HTML",
        )
        return

    page = 1
    per_page = 5
    total_pages = math.ceil(len(payments) / per_page)
    page_payments = payments[(page - 1) * per_page: page * per_page]

    text = "📋 <b>To'lov tarixi:</b>\n\n"
    for p in page_payments:
        date = p.paid_at.strftime("%d.%m.%Y") if p.paid_at else "—"
        plan_name = p.plan.name if p.plan else "—"
        text += (
            f"• {date} — {plan_name}\n"
            f"  💰 {int(p.amount):,} so'm | {p.provider.value.upper()}\n\n"
        )

    await call.message.edit_text(
        text,
        reply_markup=payment_history_kb(page, total_pages),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("pay_hist:"))
async def payment_history_page(call: CallbackQuery, user: User, db: AsyncSession):
    page = int(call.data.split(":")[1])
    pay_repo = PaymentRepo(db)
    payments = await pay_repo.get_user_history(user.id, limit=50)

    per_page = 5
    total_pages = math.ceil(len(payments) / per_page)
    page = max(1, min(page, total_pages))
    page_payments = payments[(page - 1) * per_page: page * per_page]

    text = "📋 <b>To'lov tarixi:</b>\n\n"
    for p in page_payments:
        date = p.paid_at.strftime("%d.%m.%Y") if p.paid_at else "—"
        plan_name = p.plan.name if p.plan else "—"
        text += (
            f"• {date} — {plan_name}\n"
            f"  💰 {int(p.amount):,} so'm | {p.provider.value.upper()}\n\n"
        )

    await call.message.edit_text(
        text,
        reply_markup=payment_history_kb(page, total_pages),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "profile:referrals")
async def profile_referrals(call: CallbackQuery, user: User, db: AsyncSession):
    user_repo = UserRepo(db)
    referrals = await user_repo.get_referrals(user.id)

    if not referrals:
        await call.message.edit_text(
            "👥 <b>Mening referrallarim</b>\n\n"
            "Hozircha hech kim taklif qilinmagan.\n\n"
            f"Havola: <code>https://t.me/Uzbek_seenuz_bot?start=ref_{user.referral_code}</code>",
            reply_markup=back_kb("back:profile"),
            parse_mode="HTML",
        )
        return

    text = f"👥 <b>Mening referrallarim ({len(referrals)} ta):</b>\n\n"
    for i, ref in enumerate(referrals[:20], 1):
        date = ref.created_at.strftime("%d.%m.%Y") if ref.created_at else "—"
        text += f"{i}. {ref.full_name} — {date}\n"

    await call.message.edit_text(
        text,
        reply_markup=back_kb("back:profile"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "back:profile")
async def back_to_profile(call: CallbackQuery, user: User, db: AsyncSession):
    await cmd_profile(call.message, user, db)
