from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User
from database.repo import UserRepo, ReferralRepo, WithdrawalRepo
from keyboards import balance_kb, withdraw_confirm_kb, back_kb
from config import settings

router = Router()


class WithdrawStates(StatesGroup):
    waiting_card = State()
    waiting_amount = State()
    confirm = State()


@router.message(F.text == "👥 Referral tizim")
@router.message(Command("referral"))
async def cmd_referral(message: Message, user: User, db: AsyncSession):
    ref_link = f"https://t.me/Uzbek_seenuz_bot?start=ref_{user.referral_code}"
    user_repo = UserRepo(db)
    referrals = await user_repo.get_referrals(user.id)
    ref_repo = ReferralRepo(db)
    total_earned = await ref_repo.total_for_user(user.id)

    await message.answer(
        f"👥 <b>Referral tizim</b>\n\n"
        f"Do'stlaringizni taklif qiling va bonus oling!\n\n"
        f"🎁 <b>Bonus miqdori:</b>\n"
        f"• Siz: +{int(settings.REFERRAL_BONUS_INVITER):,} so'm\n"
        f"• Do'stingiz: +{int(settings.REFERRAL_BONUS_INVITED):,} so'm\n\n"
        f"📊 <b>Statistika:</b>\n"
        f"• Taklif qilinganlar: <b>{len(referrals)}</b>\n"
        f"• Jami ishlab topilgan: <b>{int(total_earned):,} so'm</b>\n\n"
        f"🔗 <b>Sizning havolangiz:</b>\n"
        f"<code>{ref_link}</code>\n\n"
        f"↗️ Havolani nusxalash va do'stlaringizga yuborish uchun ustiga bosing!",
        parse_mode="HTML",
    )


@router.message(F.text == "💰 Balans")
@router.message(Command("balance"))
async def cmd_balance(message: Message, user: User, db: AsyncSession):
    can_withdraw = float(user.balance) >= float(settings.REFERRAL_MIN_WITHDRAW)

    await message.answer(
        f"💰 <b>Balansingiz</b>\n\n"
        f"💵 Joriy balans: <b>{int(user.balance):,} so'm</b>\n"
        f"📈 Jami ishlab topilgan: <b>{int(user.total_earned):,} so'm</b>\n\n"
        f"{'✅ Pul chiqarish mumkin!' if can_withdraw else f'⚠️ Pul chiqarish uchun minimum: {int(settings.REFERRAL_MIN_WITHDRAW):,} so'm'}\n\n"
        f"💡 Referral tizim orqali ko'proq daromad qiling!",
        reply_markup=balance_kb(can_withdraw),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "withdraw:start")
async def withdraw_start(call: CallbackQuery, user: User, state: FSMContext):
    if float(user.balance) < float(settings.REFERRAL_MIN_WITHDRAW):
        await call.answer(
            f"❌ Minimal miqdor: {int(settings.REFERRAL_MIN_WITHDRAW):,} so'm",
            show_alert=True,
        )
        return

    await state.set_state(WithdrawStates.waiting_card)
    await state.update_data(user_balance=float(user.balance))
    await call.message.edit_text(
        "💸 <b>Pul chiqarish</b>\n\n"
        "💳 Karta raqamingizni kiriting (16 raqam):\n"
        "<i>Masalan: 8600 1234 5678 9012</i>",
        reply_markup=back_kb("balance:cancel"),
        parse_mode="HTML",
    )


@router.message(WithdrawStates.waiting_card)
async def withdraw_card(message: Message, user: User, state: FSMContext):
    card = message.text.replace(" ", "").strip()
    if not card.isdigit() or len(card) != 16:
        await message.answer(
            "❌ Noto'g'ri karta raqami. 16 ta raqam kiriting:\n"
            "<i>Masalan: 8600123456789012</i>",
            parse_mode="HTML",
        )
        return

    await state.update_data(card_number=card)
    await state.set_state(WithdrawStates.waiting_amount)
    data = await state.get_data()
    balance = data.get("user_balance", 0)

    await message.answer(
        f"💵 Chiqarmoqchi bo'lgan summa (so'mda):\n\n"
        f"Mavjud balans: <b>{int(balance):,} so'm</b>\n"
        f"Minimal: <b>{int(settings.REFERRAL_MIN_WITHDRAW):,} so'm</b>\n\n"
        f"Summani kiriting:",
        parse_mode="HTML",
    )


@router.message(WithdrawStates.waiting_amount)
async def withdraw_amount(message: Message, user: User, state: FSMContext):
    try:
        amount = int(message.text.replace(",", "").replace(" ", ""))
    except ValueError:
        await message.answer("❌ Noto'g'ri summa. Faqat raqam kiriting.")
        return

    if amount < int(settings.REFERRAL_MIN_WITHDRAW):
        await message.answer(
            f"❌ Minimal summa: {int(settings.REFERRAL_MIN_WITHDRAW):,} so'm"
        )
        return

    if amount > float(user.balance):
        await message.answer(
            f"❌ Balansingiz yetarli emas!\n"
            f"Mavjud: {int(user.balance):,} so'm"
        )
        return

    data = await state.get_data()
    card = data.get("card_number")
    await state.update_data(amount=amount)

    masked_card = f"{card[:4]} **** **** {card[-4:]}"
    await message.answer(
        f"✅ <b>So'rovni tasdiqlang:</b>\n\n"
        f"💳 Karta: <code>{masked_card}</code>\n"
        f"💵 Summa: <b>{amount:,} so'm</b>\n\n"
        f"⚠️ So'rov 1-2 ish kuni ichida ko'rib chiqiladi.",
        reply_markup=withdraw_confirm_kb(amount),
        parse_mode="HTML",
    )
    await state.set_state(WithdrawStates.confirm)


@router.callback_query(F.data.startswith("withdraw:confirm:"))
async def withdraw_confirm(call: CallbackQuery, user: User, db: AsyncSession, state: FSMContext):
    amount = int(call.data.split(":")[2])
    data = await state.get_data()
    card = data.get("card_number", "")

    if amount > float(user.balance):
        await call.answer("❌ Balans yetarli emas!", show_alert=True)
        await state.clear()
        return

    # Deduct from balance immediately (hold)
    user_repo = UserRepo(db)
    await user_repo.update_balance(user.id, -amount)

    # Create withdrawal request
    withdraw_repo = WithdrawalRepo(db)
    withdrawal = await withdraw_repo.create(
        user_id=user.id,
        amount=amount,
        card_number=card,
    )

    # Notify admins
    await notify_admins_withdrawal(call.bot, withdrawal, user, card, amount)

    await state.clear()
    await call.message.edit_text(
        f"✅ <b>So'rov qabul qilindi!</b>\n\n"
        f"🆔 So'rov #: <code>{withdrawal.id}</code>\n"
        f"💵 Summa: {amount:,} so'm\n"
        f"💳 Karta: **** {card[-4:]}\n\n"
        f"⏰ 1-2 ish kuni ichida o'tkaziladi.",
        parse_mode="HTML",
    )


async def notify_admins_withdrawal(bot, withdrawal, user: User, card: str, amount: int):
    from config import settings
    from keyboards import admin_withdrawal_kb
    for admin_id in settings.ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"💸 <b>Yangi pul chiqarish so'rovi!</b>\n\n"
                f"👤 Foydalanuvchi: {user.full_name}\n"
                f"🆔 Telegram ID: <code>{user.telegram_id}</code>\n"
                f"💳 Karta: <code>{card}</code>\n"
                f"💵 Summa: {amount:,} so'm\n"
                f"🆔 So'rov ID: {withdrawal.id}",
                reply_markup=admin_withdrawal_kb(withdrawal.id),
                parse_mode="HTML",
            )
        except Exception:
            pass


@router.callback_query(F.data == "withdraw:cancel")
@router.callback_query(F.data == "balance:cancel")
async def withdraw_cancel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text("❌ Bekor qilindi.")


@router.callback_query(F.data == "balance:use")
async def balance_use_subscription(call: CallbackQuery, user: User, db: AsyncSession):
    from database.repo import PlanRepo
    from keyboards import plans_kb
    plan_repo = PlanRepo(db)
    plans = await plan_repo.get_all_active()
    await call.message.edit_text(
        f"💰 Balans: <b>{int(user.balance):,} so'm</b>\n\n"
        f"💎 Obuna uchun reja tanlang:",
        reply_markup=plans_kb(plans),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "referral:stats")
async def referral_stats(call: CallbackQuery, user: User, db: AsyncSession):
    ref_repo = ReferralRepo(db)
    bonuses = await ref_repo.get_user_bonuses(user.id)
    total = await ref_repo.total_for_user(user.id)

    text = f"📊 <b>Referral statistika</b>\n\n"
    text += f"💰 Jami bonus: <b>{int(total):,} so'm</b>\n"
    text += f"👥 Taklif soni: <b>{len(bonuses)}</b>\n\n"

    if bonuses:
        text += "<b>So'nggi taklif bonuslari:</b>\n"
        for b in bonuses[:10]:
            date = b.created_at.strftime("%d.%m.%Y") if b.created_at else "—"
            text += f"• {date} — +{int(b.amount):,} so'm\n"

    await call.message.edit_text(
        text,
        reply_markup=back_kb("back:main"),
        parse_mode="HTML",
    )
