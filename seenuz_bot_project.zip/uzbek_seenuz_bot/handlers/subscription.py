from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User, PaymentProvider
from database.repo import PlanRepo, PaymentRepo, SubscriptionRepo, UserRepo
from keyboards import plans_kb, payment_method_kb, check_payment_kb, back_kb
from services.payment import payment_gateway
from services.redis_service import redis_service
import logging

router = Router()
logger = logging.getLogger(__name__)


@router.message(F.text == "💎 Obuna olish")
@router.message(Command("subscribe"))
async def cmd_subscribe(message: Message, user: User, db: AsyncSession):
    sub_repo = SubscriptionRepo(db)
    is_active = await sub_repo.is_active(user.id)

    if is_active:
        sub = await sub_repo.get_active(user.id)
        expires = sub.expires_at.strftime("%d.%m.%Y")
        await message.answer(
            f"✅ Sizda faol obuna mavjud!\n\n"
            f"📦 Reja: <b>{sub.plan.name}</b>\n"
            f"📅 Amal qilish muddati: <b>{expires}</b>\n\n"
            f"Obunani uzaytirmoqchimisiz?",
            reply_markup=plans_kb(await PlanRepo(db).get_all_active()),
            parse_mode="HTML",
        )
        return

    plan_repo = PlanRepo(db)
    plans = await plan_repo.get_all_active()

    await message.answer(
        "💎 <b>Obuna rejalarini tanlang:</b>\n\n"
        "Quyidagi rejalardan birini tanlang 👇",
        reply_markup=plans_kb(plans),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("plan:"))
async def select_plan(call: CallbackQuery, user: User, db: AsyncSession):
    plan_id = int(call.data.split(":")[1])
    plan_repo = PlanRepo(db)
    plan = await plan_repo.get_by_id(plan_id)

    if not plan:
        await call.answer("❌ Reja topilmadi", show_alert=True)
        return

    discount_text = ""
    if plan.discount_percent:
        original = int(plan.price) * 100 // (100 - plan.discount_percent)
        discount_text = f"\n💰 Asl narx: <s>{original:,} so'm</s>\n🎁 Chegirma: {plan.discount_percent}%"

    await call.message.edit_text(
        f"📦 <b>{plan.name}</b>\n\n"
        f"💵 Narx: <b>{int(plan.price):,} so'm</b>{discount_text}\n"
        f"📅 Muddat: <b>{plan.duration_days} kun</b>\n\n"
        f"💳 To'lov usulini tanlang:",
        reply_markup=payment_method_kb(plan_id),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("pay:"))
async def select_payment_method(call: CallbackQuery, user: User, db: AsyncSession):
    parts = call.data.split(":")
    provider = parts[1]
    plan_id = int(parts[2])

    plan_repo = PlanRepo(db)
    plan = await plan_repo.get_by_id(plan_id)
    if not plan:
        await call.answer("❌ Xatolik yuz berdi", show_alert=True)
        return

    if provider == "balance":
        # Check balance
        if float(user.balance) < float(plan.price):
            await call.answer(
                f"❌ Balansingiz yetarli emas!\n"
                f"Balans: {int(user.balance):,} so'm\n"
                f"Kerak: {int(plan.price):,} so'm",
                show_alert=True,
            )
            return

        # Deduct balance and create subscription
        pay_repo = PaymentRepo(db)
        payment = await pay_repo.create(
            user_id=user.id,
            plan_id=plan_id,
            provider=PaymentProvider.REFERRAL,
            amount=float(plan.price),
            description=f"Balans orqali {plan.name} obuna",
        )
        await pay_repo.mark_paid(payment.id, "balance")
        user_repo = UserRepo(db)
        await user_repo.update_balance(user.id, -float(plan.price))
        sub_repo = SubscriptionRepo(db)
        await sub_repo.create(user.id, plan_id, payment.id)

        await call.message.edit_text(
            f"✅ <b>Obuna muvaffaqiyatli faollashtirildi!</b>\n\n"
            f"📦 Reja: {plan.name}\n"
            f"💰 To'langan: {int(plan.price):,} so'm (balansdan)\n\n"
            f"Xizmatdan rohatlaning! 🎬",
            parse_mode="HTML",
        )
        return

    # Create payment record
    pay_repo = PaymentRepo(db)
    payment = await pay_repo.create(
        user_id=user.id,
        plan_id=plan_id,
        provider=PaymentProvider(provider),
        amount=float(plan.price),
        description=f"{plan.name} obuna - {provider}",
    )

    # Generate payment URL
    pay_url = payment_gateway.get_payment_url(
        provider=provider,
        order_id=payment.order_id,
        amount=int(plan.price),
        description=f"{plan.name} obuna",
    )

    # Cache pending payment
    await redis_service.set_pending_payment(user.id, {
        "payment_id": payment.id,
        "order_id": payment.order_id,
        "plan_id": plan_id,
        "provider": provider,
        "amount": int(plan.price),
    })

    provider_names = {
        "payme": "💳 Payme",
        "click": "🔵 Click",
        "uzum": "🟠 Uzum Bank",
    }

    await call.message.edit_text(
        f"💳 <b>{provider_names.get(provider, provider)} orqali to'lov</b>\n\n"
        f"📦 Reja: <b>{plan.name}</b>\n"
        f"💵 Summa: <b>{int(plan.price):,} so'm</b>\n"
        f"🆔 Buyurtma: <code>{payment.order_id}</code>\n\n"
        f"👇 Quyidagi tugmani bosib to'lovni amalga oshiring:",
        reply_markup=check_payment_kb(payment.order_id, pay_url),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("check_pay:"))
async def check_payment(call: CallbackQuery, user: User, db: AsyncSession):
    order_id = call.data.split(":", 1)[1]

    await call.answer("🔄 Tekshirilmoqda...")

    pay_repo = PaymentRepo(db)
    payment = await pay_repo.get_by_order_id(order_id)

    if not payment or payment.user_id != user.id:
        await call.answer("❌ To'lov topilmadi", show_alert=True)
        return

    # Check with payment provider
    is_paid = await payment_gateway.check_payment(payment.provider.value, order_id)

    if is_paid:
        updated = await pay_repo.mark_paid(payment.id, order_id)
        sub_repo = SubscriptionRepo(db)
        await sub_repo.create(user.id, payment.plan_id, payment.id)
        await redis_service.clear_pending_payment(user.id)
        await redis_service.delete(f"sub:{user.id}")

        plan = await PlanRepo(db).get_by_id(payment.plan_id)

        await call.message.edit_text(
            f"✅ <b>To'lov qabul qilindi!</b>\n\n"
            f"🎉 Obunangiz muvaffaqiyatli faollashtirildi!\n"
            f"📦 Reja: {plan.name}\n"
            f"💰 To'langan: {int(payment.amount):,} so'm\n\n"
            f"Xizmatdan rohatlaning! 🎬",
            parse_mode="HTML",
        )
        logger.info(f"Payment confirmed: user={user.id}, order={order_id}")
    else:
        await call.answer(
            "⏳ To'lov hali amalga oshmagan. Biroz kuting yoki to'lovni bajaring.",
            show_alert=True,
        )


@router.callback_query(F.data.startswith("cancel_pay:"))
async def cancel_payment(call: CallbackQuery, user: User, db: AsyncSession):
    await redis_service.clear_pending_payment(user.id)
    await call.message.edit_text(
        "❌ To'lov bekor qilindi.\n\n"
        "Obuna olish uchun /subscribe buyrug'ini yuboring.",
    )


@router.callback_query(F.data == "back:plans")
async def back_to_plans(call: CallbackQuery, user: User, db: AsyncSession):
    plan_repo = PlanRepo(db)
    plans = await plan_repo.get_all_active()
    await call.message.edit_text(
        "💎 <b>Obuna rejalarini tanlang:</b>\n\n"
        "Quyidagi rejalardan birini tanlang 👇",
        reply_markup=plans_kb(plans),
        parse_mode="HTML",
    )
