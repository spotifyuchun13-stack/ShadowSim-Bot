from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func, and_, desc
from sqlalchemy.orm import selectinload
from datetime import datetime, timedelta, timezone
from typing import Optional, List
import random
import string

from database.models import (
    User, SubscriptionPlan, Subscription, Payment, ReferralBonus,
    Withdrawal, Notification, SubscriptionStatus, PaymentStatus,
    PaymentProvider, WithdrawStatus
)


def generate_referral_code(length: int = 8) -> str:
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


def generate_order_id() -> str:
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    rand = ''.join(random.choices(string.digits, k=6))
    return f"ORD-{ts}-{rand}"


# ─── USER REPO ────────────────────────────────────────────────────────────────

class UserRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.db.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_by_referral_code(self, code: str) -> Optional[User]:
        result = await self.db.execute(
            select(User).where(User.referral_code == code)
        )
        return result.scalar_one_or_none()

    async def create(self, telegram_id: int, full_name: str,
                     username: Optional[str] = None,
                     referred_by_id: Optional[int] = None) -> User:
        code = generate_referral_code()
        # ensure uniqueness
        while await self.get_by_referral_code(code):
            code = generate_referral_code()

        user = User(
            telegram_id=telegram_id,
            full_name=full_name,
            username=username,
            referral_code=code,
            referred_by_id=referred_by_id,
        )
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user

    async def get_or_create(self, telegram_id: int, full_name: str,
                             username: Optional[str] = None,
                             referral_code: Optional[str] = None) -> tuple[User, bool]:
        user = await self.get_by_telegram_id(telegram_id)
        if user:
            await self.db.execute(
                update(User).where(User.telegram_id == telegram_id)
                .values(last_active=func.now(), full_name=full_name, username=username)
            )
            await self.db.commit()
            return user, False

        referred_by_id = None
        if referral_code:
            referrer = await self.get_by_referral_code(referral_code)
            if referrer and referrer.telegram_id != telegram_id:
                referred_by_id = referrer.id

        user = await self.create(telegram_id, full_name, username, referred_by_id)
        return user, True

    async def update_balance(self, user_id: int, amount: float) -> User:
        await self.db.execute(
            update(User).where(User.id == user_id)
            .values(
                balance=User.balance + amount,
                total_earned=User.total_earned + (amount if amount > 0 else 0)
            )
        )
        await self.db.commit()
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one()

    async def get_referrals(self, user_id: int) -> List[User]:
        result = await self.db.execute(
            select(User).where(User.referred_by_id == user_id)
            .order_by(desc(User.created_at))
        )
        return result.scalars().all()

    async def get_all_active(self) -> List[User]:
        result = await self.db.execute(
            select(User).where(User.is_active == True, User.is_banned == False)
        )
        return result.scalars().all()

    async def count_total(self) -> int:
        result = await self.db.execute(select(func.count(User.id)))
        return result.scalar()

    async def ban(self, user_id: int):
        await self.db.execute(
            update(User).where(User.id == user_id).values(is_banned=True)
        )
        await self.db.commit()


# ─── PLAN REPO ────────────────────────────────────────────────────────────────

class PlanRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_all_active(self) -> List[SubscriptionPlan]:
        result = await self.db.execute(
            select(SubscriptionPlan)
            .where(SubscriptionPlan.is_active == True)
            .order_by(SubscriptionPlan.sort_order)
        )
        return result.scalars().all()

    async def get_by_id(self, plan_id: int) -> Optional[SubscriptionPlan]:
        result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == plan_id)
        )
        return result.scalar_one_or_none()

    async def seed_default_plans(self):
        existing = await self.get_all_active()
        if existing:
            return
        plans = [
            SubscriptionPlan(name="1 Oylik", duration_days=30,
                             price=15000, sort_order=1,
                             description="1 oylik to'liq obuna"),
            SubscriptionPlan(name="3 Oylik", duration_days=90,
                             price=35000, discount_percent=22, sort_order=2,
                             description="3 oylik obuna — 22% chegirma"),
            SubscriptionPlan(name="6 Oylik", duration_days=180,
                             price=60000, discount_percent=33, sort_order=3,
                             description="6 oylik obuna — 33% chegirma"),
            SubscriptionPlan(name="12 Oylik", duration_days=365,
                             price=100000, discount_percent=44, sort_order=4,
                             description="Yillik obuna — 44% chegirma"),
        ]
        for p in plans:
            self.db.add(p)
        await self.db.commit()


# ─── SUBSCRIPTION REPO ───────────────────────────────────────────────────────

class SubscriptionRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_active(self, user_id: int) -> Optional[Subscription]:
        now = datetime.now(timezone.utc)
        result = await self.db.execute(
            select(Subscription)
            .options(selectinload(Subscription.plan))
            .where(
                Subscription.user_id == user_id,
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at > now,
            )
            .order_by(desc(Subscription.expires_at))
        )
        return result.scalars().first()

    async def create(self, user_id: int, plan_id: int, payment_id: int) -> Subscription:
        plan_result = await self.db.execute(
            select(SubscriptionPlan).where(SubscriptionPlan.id == plan_id)
        )
        plan = plan_result.scalar_one()

        # Check if extending existing
        existing = await self.get_active(user_id)
        if existing:
            start = existing.expires_at
        else:
            start = datetime.now(timezone.utc)

        expires = start + timedelta(days=plan.duration_days)
        sub = Subscription(
            user_id=user_id,
            plan_id=plan_id,
            status=SubscriptionStatus.ACTIVE,
            started_at=start,
            expires_at=expires,
            payment_id=payment_id,
        )
        self.db.add(sub)
        await self.db.commit()
        await self.db.refresh(sub)
        return sub

    async def is_active(self, user_id: int) -> bool:
        sub = await self.get_active(user_id)
        return sub is not None

    async def expire_old(self):
        """Called by scheduler to expire subscriptions."""
        now = datetime.now(timezone.utc)
        await self.db.execute(
            update(Subscription)
            .where(
                Subscription.status == SubscriptionStatus.ACTIVE,
                Subscription.expires_at <= now,
            )
            .values(status=SubscriptionStatus.EXPIRED)
        )
        await self.db.commit()


# ─── PAYMENT REPO ────────────────────────────────────────────────────────────

class PaymentRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, user_id: int, plan_id: int,
                     provider: PaymentProvider, amount: float,
                     description: str = "") -> Payment:
        payment = Payment(
            user_id=user_id,
            plan_id=plan_id,
            provider=provider,
            amount=amount,
            order_id=generate_order_id(),
            description=description,
        )
        self.db.add(payment)
        await self.db.commit()
        await self.db.refresh(payment)
        return payment

    async def get_by_order_id(self, order_id: str) -> Optional[Payment]:
        result = await self.db.execute(
            select(Payment).where(Payment.order_id == order_id)
        )
        return result.scalar_one_or_none()

    async def mark_paid(self, payment_id: int, external_id: str = "") -> Payment:
        await self.db.execute(
            update(Payment).where(Payment.id == payment_id)
            .values(
                status=PaymentStatus.PAID,
                external_id=external_id,
                paid_at=func.now(),
            )
        )
        await self.db.commit()
        result = await self.db.execute(select(Payment).where(Payment.id == payment_id))
        return result.scalar_one()

    async def get_user_history(self, user_id: int, limit: int = 10) -> List[Payment]:
        result = await self.db.execute(
            select(Payment)
            .options(selectinload(Payment.plan))
            .where(Payment.user_id == user_id, Payment.status == PaymentStatus.PAID)
            .order_by(desc(Payment.paid_at))
            .limit(limit)
        )
        return result.scalars().all()

    async def total_revenue(self) -> float:
        result = await self.db.execute(
            select(func.sum(Payment.amount))
            .where(Payment.status == PaymentStatus.PAID)
        )
        return float(result.scalar() or 0)


# ─── REFERRAL REPO ───────────────────────────────────────────────────────────

class ReferralRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_bonus(self, user_id: int, invited_user_id: int, amount: float) -> ReferralBonus:
        bonus = ReferralBonus(
            user_id=user_id,
            invited_user_id=invited_user_id,
            amount=amount,
            is_credited=True,
        )
        self.db.add(bonus)
        await self.db.commit()
        await self.db.refresh(bonus)
        return bonus

    async def get_user_bonuses(self, user_id: int) -> List[ReferralBonus]:
        result = await self.db.execute(
            select(ReferralBonus)
            .where(ReferralBonus.user_id == user_id)
            .order_by(desc(ReferralBonus.created_at))
        )
        return result.scalars().all()

    async def total_for_user(self, user_id: int) -> float:
        result = await self.db.execute(
            select(func.sum(ReferralBonus.amount))
            .where(ReferralBonus.user_id == user_id)
        )
        return float(result.scalar() or 0)


# ─── WITHDRAWAL REPO ─────────────────────────────────────────────────────────

class WithdrawalRepo:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, user_id: int, amount: float, card_number: str,
                     card_holder: str = "") -> Withdrawal:
        w = Withdrawal(
            user_id=user_id,
            amount=amount,
            card_number=card_number,
            card_holder=card_holder,
        )
        self.db.add(w)
        await self.db.commit()
        await self.db.refresh(w)
        return w

    async def get_pending(self) -> List[Withdrawal]:
        result = await self.db.execute(
            select(Withdrawal)
            .options(selectinload(Withdrawal.user))
            .where(Withdrawal.status == WithdrawStatus.PENDING)
            .order_by(Withdrawal.created_at)
        )
        return result.scalars().all()

    async def approve(self, withdrawal_id: int, admin_note: str = ""):
        await self.db.execute(
            update(Withdrawal).where(Withdrawal.id == withdrawal_id)
            .values(
                status=WithdrawStatus.APPROVED,
                admin_note=admin_note,
                processed_at=func.now(),
            )
        )
        await self.db.commit()

    async def reject(self, withdrawal_id: int, admin_note: str = ""):
        await self.db.execute(
            update(Withdrawal).where(Withdrawal.id == withdrawal_id)
            .values(status=WithdrawStatus.REJECTED, admin_note=admin_note,
                    processed_at=func.now())
        )
        await self.db.commit()
