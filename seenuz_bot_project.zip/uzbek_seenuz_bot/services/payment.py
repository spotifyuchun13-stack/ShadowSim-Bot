"""
Payment service integrations:
- Payme (Subscribe)
- Click (Merchant API)
- Uzum Bank (formerly Apelsin)
"""
import hashlib
import hmac
import json
import base64
import aiohttp
from typing import Optional, Dict, Any
from config import settings


class PaymeService:
    """
    Payme Subscribe integration.
    Docs: https://developer.help.paycom.uz/ru/subscribe-api
    """
    BASE_URL = "https://checkout.paycom.uz"
    TEST_URL = "https://test.paycom.uz"

    @property
    def checkout_url(self) -> str:
        return self.TEST_URL if settings.PAYME_IS_TEST else self.BASE_URL

    def generate_link(self, order_id: str, amount: int, description: str = "") -> str:
        """Generate Payme checkout link. Amount in UZS tiyin (x100)."""
        amount_tiyin = amount * 100
        params = {
            "m": settings.PAYME_MERCHANT_ID,
            "ac.order_id": order_id,
            "a": amount_tiyin,
            "l": "uz",
            "ct": 15 * 60,  # 15 min timeout
        }
        encoded = base64.b64encode(
            json.dumps(params).encode()
        ).decode()
        return f"{self.checkout_url}/{encoded}"

    def verify_callback(self, data: Dict, auth_header: str) -> bool:
        """Verify Payme callback signature."""
        key = settings.PAYME_TEST_SECRET_KEY if settings.PAYME_IS_TEST else settings.PAYME_SECRET_KEY
        encoded = base64.b64encode(
            f"{settings.PAYME_MERCHANT_ID}:{key}".encode()
        ).decode()
        expected = f"Basic {encoded}"
        return auth_header == expected

    async def check_payment(self, order_id: str) -> Optional[str]:
        """Check payment status via Payme API. Returns transaction ID if paid."""
        key = settings.PAYME_TEST_SECRET_KEY if settings.PAYME_IS_TEST else settings.PAYME_SECRET_KEY
        auth = base64.b64encode(
            f"{settings.PAYME_MERCHANT_ID}:{key}".encode()
        ).decode()
        headers = {
            "X-Auth": auth,
            "Content-Type": "application/json",
        }
        payload = {
            "id": 1,
            "method": "CheckTransaction",
            "params": {"id": order_id},
        }
        api_url = "https://checkout.test.paycom.uz/api" if settings.PAYME_IS_TEST else "https://checkout.paycom.uz/api"
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(api_url, json=payload, headers=headers) as resp:
                    data = await resp.json()
                    result = data.get("result", {})
                    # state 2 = completed/paid
                    if result.get("state") == 2:
                        return str(result.get("id"))
                    return None
            except Exception:
                return None


class ClickService:
    """
    Click Merchant API integration.
    Docs: https://docs.click.uz/
    """

    def generate_link(self, order_id: str, amount: int, description: str = "") -> str:
        """Generate Click payment link. Amount in UZS."""
        return (
            f"https://my.click.uz/services/pay"
            f"?service_id={settings.CLICK_SERVICE_ID}"
            f"&merchant_id={settings.CLICK_MERCHANT_ID}"
            f"&amount={amount}"
            f"&transaction_param={order_id}"
            f"&return_url=https://t.me/{settings.BOT_USERNAME}"
        )

    def verify_sign(self, click_trans_id: str, service_id: str,
                    secret_key: str, merchant_trans_id: str,
                    amount: str, action: str, sign_time: str,
                    sign_string: str) -> bool:
        """Verify Click callback signature."""
        my_sign = hashlib.md5(
            f"{click_trans_id}{service_id}{secret_key}{merchant_trans_id}{amount}{action}{sign_time}".encode()
        ).hexdigest()
        return my_sign == sign_string

    async def check_payment(self, order_id: str) -> bool:
        """Check payment status via Click API."""
        auth = hashlib.md5(
            f"{settings.CLICK_MERCHANT_USER_ID}{settings.CLICK_SECRET_KEY}".encode()
        ).hexdigest()
        headers = {
            "Auth": f"{settings.CLICK_MERCHANT_USER_ID}:{auth}",
            "Content-Type": "application/json",
        }
        url = f"https://api.click.uz/v2/merchant/payment/status/{settings.CLICK_SERVICE_ID}/{order_id}"
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=headers) as resp:
                    data = await resp.json()
                    return data.get("payment_status") == 2  # 2 = paid
            except Exception:
                return False


class UzumService:
    """
    Uzum Bank (formerly Apelsin) payment integration.
    """

    def generate_link(self, order_id: str, amount: int, description: str = "") -> str:
        """Generate Uzum payment link."""
        return (
            f"https://merchant.uzum.uz/pay"
            f"?merchant={settings.UZUM_MERCHANT_ID}"
            f"&amount={amount * 100}"
            f"&account={order_id}"
        )

    def verify_sign(self, data: Dict, received_sign: str) -> bool:
        """Verify Uzum webhook signature."""
        payload = json.dumps(data, separators=(",", ":"), sort_keys=True)
        expected = hmac.new(
            settings.UZUM_SECRET_KEY.encode(),
            payload.encode(),
            hashlib.sha256,
        ).hexdigest()
        return expected == received_sign


class PaymentGateway:
    """Unified gateway for all payment providers."""

    def __init__(self):
        self.payme = PaymeService()
        self.click = ClickService()
        self.uzum = UzumService()

    def get_payment_url(self, provider: str, order_id: str, amount: int, description: str = "") -> str:
        if provider == "payme":
            return self.payme.generate_link(order_id, amount, description)
        elif provider == "click":
            return self.click.generate_link(order_id, amount, description)
        elif provider == "uzum":
            return self.uzum.generate_link(order_id, amount, description)
        raise ValueError(f"Unknown provider: {provider}")

    async def check_payment(self, provider: str, order_id: str) -> bool:
        if provider == "payme":
            result = await self.payme.check_payment(order_id)
            return result is not None
        elif provider == "click":
            return await self.click.check_payment(order_id)
        return False


payment_gateway = PaymentGateway()
