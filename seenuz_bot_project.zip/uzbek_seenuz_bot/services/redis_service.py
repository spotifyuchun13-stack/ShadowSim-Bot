import redis.asyncio as aioredis
import json
from typing import Optional, Any
from config import settings


class RedisService:
    def __init__(self):
        self._redis: Optional[aioredis.Redis] = None

    async def connect(self):
        self._redis = await aioredis.from_url(
            settings.REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
        )

    async def disconnect(self):
        if self._redis:
            await self._redis.close()

    @property
    def redis(self) -> aioredis.Redis:
        if not self._redis:
            raise RuntimeError("Redis not connected")
        return self._redis

    # ── Generic ──────────────────────────────────────────────────────────────

    async def set(self, key: str, value: Any, ttl: int = 3600):
        await self.redis.setex(key, ttl, json.dumps(value))

    async def get(self, key: str) -> Optional[Any]:
        data = await self.redis.get(key)
        return json.loads(data) if data else None

    async def delete(self, key: str):
        await self.redis.delete(key)

    async def exists(self, key: str) -> bool:
        return bool(await self.redis.exists(key))

    # ── User state (FSM alternative for simple states) ───────────────────────

    async def set_user_state(self, user_id: int, state: str, ttl: int = 600):
        await self.set(f"state:{user_id}", state, ttl)

    async def get_user_state(self, user_id: int) -> Optional[str]:
        return await self.get(f"state:{user_id}")

    async def clear_user_state(self, user_id: int):
        await self.delete(f"state:{user_id}")

    # ── User data cache ───────────────────────────────────────────────────────

    async def cache_user(self, user_id: int, data: dict, ttl: int = 300):
        await self.set(f"user:{user_id}", data, ttl)

    async def get_cached_user(self, user_id: int) -> Optional[dict]:
        return await self.get(f"user:{user_id}")

    async def invalidate_user(self, user_id: int):
        await self.delete(f"user:{user_id}")

    # ── Subscription cache ────────────────────────────────────────────────────

    async def cache_subscription_status(self, user_id: int, is_active: bool, ttl: int = 60):
        await self.set(f"sub:{user_id}", is_active, ttl)

    async def get_subscription_status(self, user_id: int) -> Optional[bool]:
        return await self.get(f"sub:{user_id}")

    # ── Payment pending ───────────────────────────────────────────────────────

    async def set_pending_payment(self, user_id: int, payment_data: dict, ttl: int = 900):
        """Store pending payment for 15 minutes."""
        await self.set(f"pending_pay:{user_id}", payment_data, ttl)

    async def get_pending_payment(self, user_id: int) -> Optional[dict]:
        return await self.get(f"pending_pay:{user_id}")

    async def clear_pending_payment(self, user_id: int):
        await self.delete(f"pending_pay:{user_id}")

    # ── Rate limiting ─────────────────────────────────────────────────────────

    async def check_rate_limit(self, key: str, limit: int, window: int) -> bool:
        """Returns True if rate limit exceeded."""
        current = await self.redis.incr(f"rl:{key}")
        if current == 1:
            await self.redis.expire(f"rl:{key}", window)
        return current > limit

    # ── Anti-spam ─────────────────────────────────────────────────────────────

    async def mark_spam(self, user_id: int, ttl: int = 30):
        await self.redis.setex(f"spam:{user_id}", ttl, 1)

    async def is_spam(self, user_id: int) -> bool:
        return await self.exists(f"spam:{user_id}")

    # ── Broadcast ────────────────────────────────────────────────────────────

    async def set_broadcast_message(self, admin_id: int, message: dict, ttl: int = 300):
        await self.set(f"broadcast:{admin_id}", message, ttl)

    async def get_broadcast_message(self, admin_id: int) -> Optional[dict]:
        return await self.get(f"broadcast:{admin_id}")


redis_service = RedisService()
